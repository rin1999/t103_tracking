/*
  ThreeVector.hh
*/

#ifndef ThreeVector_h

#define ThreeVector_h 1

#include <CLHEP/Vector/ThreeVector.h>
//#include <CLHEP/Vector/ThreeVector.h>

typedef CLHEP::Hep3Vector ThreeVector;

#endif
